// ===== CHATLY i18n — Internationalization =====

const TRANSLATIONS = {
  ru: {
    // Auth
    auth_subtitle: 'Современный мессенджер для всех',
    login: 'Войти',
    register_tab: 'Регистрация',
    ph_username: 'Имя пользователя',
    ph_password: 'Пароль',
    login_btn: 'Войти →',
    ph_displayname: 'Ваше имя',
    ph_username_login: 'Имя пользователя (логин)',
    ph_password_min: 'Пароль (мин. 4 символа)',
    register_btn: 'Создать аккаунт ✨',
    err_connection: 'Ошибка соединения с сервером',
    err_taken: 'Имя пользователя уже занято',
    err_invalid: 'Неверные данные',
    err_fields: 'Все поля обязательны',
    err_short_user: 'Имя мин. 3 символа',
    err_short_pass: 'Пароль мин. 4 символа',

    // App
    ph_search: 'Поиск пользователей...',
    online: 'online',
    offline: 'offline',

    // Empty state
    welcome_title: 'Добро пожаловать в Chatly!',
    welcome_subtitle: 'Выберите чат слева, чтобы начать общение',
    feat_fast: 'Быстрые сообщения',
    feat_secure: 'Безопасный чат',

    // Chat
    ph_message: 'Написать сообщение...',
    typing: 'печатает...',
    no_messages: 'Нет сообщений',

    // Date
    today: 'Сегодня',
    yesterday: 'Вчера',

    // Settings
    settings: 'Настройки',
    tab_profile: 'Профиль',
    tab_theme: 'Тема',
    label_name: 'Имя',
    label_bio: 'О себе',
    ph_bio: 'Расскажите о себе...',
    label_login: 'Логин',
    label_status: 'Статус',
    save_changes: 'Сохранить изменения',
    logout: 'Выйти',

    // Theme
    theme_default: 'Стандартная',
    theme_select: '🎨 Выберите тему для чата',
    theme_pro_only: '💎 Кастомные темы доступны в Chatly PRO',
    theme_need_pro: '💎 Нужен Chatly PRO для этой темы',

    // PRO
    pro_tagline: 'Разблокируй все возможности!',
    pro_f1: 'Кастомные темы',
    pro_f1d: 'Midnight, Ocean, Sunset, Forest, Neon',
    pro_f2: 'Реакции',
    pro_f2d: 'ставьте эмодзи-реакции на сообщения',
    pro_f3: 'Статус прочитания',
    pro_f3d: 'видьте когда сообщения прочитаны',
    pro_f4: 'Закрепление',
    pro_f4d: 'закрепляйте важные сообщения',
    pro_f5: 'PRO бейдж',
    pro_f5d: 'выделяйтесь среди других',
    pro_f6: 'Уникальный стиль',
    pro_f6d: 'кастомный цвет сообщений',
    pro_active: '💎 Chatly PRO активен!',
    pro_active_sub: 'Все премиум функции разблокированы',
    pro_free: '🆓 Бесплатный аккаунт',
    pro_free_sub: 'Обновите до PRO для расширенного функционала',
    pro_pending: '⏳ Запрос на PRO ожидает подтверждения',
    pro_pending_sub: 'Администратор рассмотрит ваш запрос',
    pro_request_btn: '🚀 Отправить запрос на PRO',
    pro_request_sent: '✅ Запрос на PRO отправлен! Ожидайте подтверждения администратора.',
    pro_already_pending: '⏳ Запрос уже ожидает подтверждения',
    pro_granted_toast: '💎 Добро пожаловать в Chatly PRO!',
    pro_removed_toast: '🔻 PRO подписка отменена',
    pro_already: 'У вас уже есть PRO',

    // Profile
    profile_saved: '✅ Профиль обновлён!',
    profile_error: '❌ Ошибка сохранения',
    copied: '📋 Скопировано!',

    // Context
    ctx_react: '😍 Реакция',
    ctx_pin: '📌 Закрепить/Открепить',
    ctx_copy: '📋 Копировать',
    pinned: '📌 Закреплено'
  },

  ua: {
    // Auth
    auth_subtitle: 'Сучасний месенджер для всіх',
    login: 'Увійти',
    register_tab: 'Реєстрація',
    ph_username: "Ім'я користувача",
    ph_password: 'Пароль',
    login_btn: 'Увійти →',
    ph_displayname: "Ваше ім'я",
    ph_username_login: "Ім'я користувача (логін)",
    ph_password_min: 'Пароль (мін. 4 символи)',
    register_btn: 'Створити акаунт ✨',
    err_connection: "Помилка з'єднання з сервером",
    err_taken: "Ім'я користувача вже зайнято",
    err_invalid: 'Невірні дані',
    err_fields: "Усі поля обов'язкові",
    err_short_user: "Ім'я мін. 3 символи",
    err_short_pass: 'Пароль мін. 4 символи',

    // App
    ph_search: 'Пошук користувачів...',
    online: 'online',
    offline: 'offline',

    // Empty state
    welcome_title: 'Ласкаво просимо в Chatly!',
    welcome_subtitle: 'Оберіть чат зліва, щоб почати спілкування',
    feat_fast: 'Швидкі повідомлення',
    feat_secure: 'Безпечний чат',

    // Chat
    ph_message: 'Написати повідомлення...',
    typing: 'друкує...',
    no_messages: 'Немає повідомлень',

    // Date
    today: 'Сьогодні',
    yesterday: 'Вчора',

    // Settings
    settings: 'Налаштування',
    tab_profile: 'Профіль',
    tab_theme: 'Тема',
    label_name: "Ім'я",
    label_bio: 'Про себе',
    ph_bio: 'Розкажіть про себе...',
    label_login: 'Логін',
    label_status: 'Статус',
    save_changes: 'Зберегти зміни',
    logout: 'Вийти',

    // Theme
    theme_default: 'Стандартна',
    theme_select: '🎨 Оберіть тему для чату',
    theme_pro_only: '💎 Кастомні теми доступні в Chatly PRO',
    theme_need_pro: '💎 Потрібен Chatly PRO для цієї теми',

    // PRO
    pro_tagline: 'Розблокуй усі можливості!',
    pro_f1: 'Кастомні теми',
    pro_f1d: 'Midnight, Ocean, Sunset, Forest, Neon',
    pro_f2: 'Реакції',
    pro_f2d: 'ставте емодзі-реакції на повідомлення',
    pro_f3: 'Статус прочитання',
    pro_f3d: 'бачте коли повідомлення прочитані',
    pro_f4: 'Закріплення',
    pro_f4d: 'закріплюйте важливі повідомлення',
    pro_f5: 'PRO бейдж',
    pro_f5d: 'виділяйтесь серед інших',
    pro_f6: 'Унікальний стиль',
    pro_f6d: 'кастомний колір повідомлень',
    pro_active: '💎 Chatly PRO активний!',
    pro_active_sub: 'Усі преміум функції розблоковані',
    pro_free: '🆓 Безкоштовний акаунт',
    pro_free_sub: 'Оновіть до PRO для розширеного функціоналу',
    pro_pending: '⏳ Запит на PRO очікує підтвердження',
    pro_pending_sub: 'Адміністратор розгляне ваш запит',
    pro_request_btn: '🚀 Відправити запит на PRO',
    pro_request_sent: '✅ Запит на PRO відправлено! Чекайте підтвердження адміністратора.',
    pro_already_pending: '⏳ Запит вже очікує підтвердження',
    pro_granted_toast: '💎 Ласкаво просимо в Chatly PRO!',
    pro_removed_toast: '🔻 PRO підписку скасовано',
    pro_already: 'У вас вже є PRO',

    // Profile
    profile_saved: '✅ Профіль оновлено!',
    profile_error: '❌ Помилка збереження',
    copied: '📋 Скопійовано!',

    // Context
    ctx_react: '😍 Реакція',
    ctx_pin: '📌 Закріпити/Відкріпити',
    ctx_copy: '📋 Копіювати',
    pinned: '📌 Закріплено'
  }
};

let currentLang = localStorage.getItem('chatly_lang') || 'ru';

function t(key) {
  return TRANSLATIONS[currentLang]?.[key] || TRANSLATIONS['ru']?.[key] || key;
}

function setLang(lang) {
  currentLang = lang;
  localStorage.setItem('chatly_lang', lang);
  applyTranslations();
  updateLangButtons();
}

function applyTranslations() {
  // Translate text content
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (TRANSLATIONS[currentLang]?.[key]) {
      el.textContent = TRANSLATIONS[currentLang][key];
    }
  });

  // Translate placeholders
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    const key = el.getAttribute('data-i18n-placeholder');
    if (TRANSLATIONS[currentLang]?.[key]) {
      el.placeholder = TRANSLATIONS[currentLang][key];
    }
  });
}

function updateLangButtons() {
  document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.lang === currentLang);
  });
}

// Setup language buttons on page load
document.addEventListener('DOMContentLoaded', () => {
  updateLangButtons();

  document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      setLang(btn.dataset.lang);
      // Re-render contacts if loaded
      const container = document.getElementById('contacts-list');
      if (container._users) {
        renderContacts(container._users);
      }
      // Re-render messages if chat open
      if (activeChat) {
        loadMessages(activeChat);
      }
      // Update PRO status
      if (currentUser) {
        updateProStatus();
      }
    });
  });

  // Apply initial translations
  applyTranslations();
});
