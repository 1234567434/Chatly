// ===== CHATLY MESSENGER - CLIENT =====

const API = '';
let token = localStorage.getItem('chatly_token');
let currentUser = null;
let activeChat = null;
let socket = null;
let typingTimeout = null;
let unreadCounts = {};
let lastMessages = {};
let onlineUsers = new Set();
let proRequestPending = false;
let contextMsgId = null;

// ===== EMOJIS =====
const EMOJIS = {
  smileys: ['😀','😃','😄','😁','😆','😅','🤣','😂','🙂','😊','😇','🥰','😍','🤩','😘','😗','😚','😙','🥲','😋','😛','😜','🤪','😝','🤑','🤗','🤭','🤫','🤔','🫡','🤐','🤨','😐','😑','😶','🫥','😏','😒','🙄','😬','🤥','😌','😔','😪','🤤','😴','😷','🤒','🤕','🤢','🤮','🥴','😵','🤯','🤠','🥳','🥸','😎','🤓','🧐','😕','🫤','😟','🙁','😮','😯','😲','😳','🥺','🥹','😦','😧','😨','😰','😥','😢','😭','😱','😖','😣','😞','😓','😩','😫','🥱','😤','😡','😠','🤬','😈','👿','💀','☠️','💩','🤡','👹','👺','👻','👽','👾','🤖'],
  hearts: ['❤️','🧡','💛','💚','💙','💜','🖤','🤍','🤎','💔','❤️‍🔥','❤️‍🩹','❣️','💕','💞','💓','💗','💖','💘','💝','💟','♥️','🫶','👍','👎','👊','✊','🤛','🤜','👏','🙌','🫵','🤝','🙏','✌️','🤞','🫰','🤟','🤘','👌','🤌','🤏','👈','👉','👆','👇','☝️','✋','🤚','🖐','🖖','🫱','🫲','👋','🤙','💪','🦾'],
  hands: ['👍','👎','👊','✊','🤛','🤜','👏','🙌','🫵','🤝','🙏','✌️','🤞','🤟','🤘','👌','🤌','🤏','👈','👉','👆','👇','☝️','✋','🤚','🖐','🖖','👋','🤙','💪','💅','🤳','💃','🕺','🫂'],
  objects: ['🎉','🎊','🎈','🎁','🏆','🥇','🥈','🥉','⚽','🏀','🏈','⚾','🎾','🏐','🎱','🏓','🎯','🎮','🕹️','🎲','♟️','🎭','🎨','🎬','🎤','🎧','🎵','🎶','🎼','🎹','🎸','🎺','🥁','🪘','🎷','🪗','🪕','🎻','🪈','🔮','🧿','🪄','✨','⭐','🌟','💫','🪩','🔥','💧','🌊','⚡','💥','☀️','🌙','🌈','🦋','🌸','🌺','🍀'],
  nature: ['🌟','✨','💫','⭐','🌙','☀️','🌈','🔥','💧','🌊','⚡','❄️','🌸','🌺','🌻','🌹','🌷','💐','🦋','🐝','🐞','🦊','🐺','🐱','🐶','🐼','🐨','🦁','🐯','🐮','🐷','🐸','🐵','🐔','🐧','🐦','🦅','🦆','🦉','🐍','🐢','🦎','🐙','🐠','🐟','🐡','🐬','🐳','🐋','🦈','🐊','🐘','🦒','🦏','🐫','🦙','🦘','🦡']
};

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
  if (token) {
    loadApp();
  } else {
    showAuth();
  }
  setupEventListeners();
});

// ===== AUTH =====
function showAuth() {
  document.getElementById('auth-screen').classList.remove('hidden');
  document.getElementById('app-screen').classList.add('hidden');
}

function showApp() {
  document.getElementById('auth-screen').classList.add('hidden');
  document.getElementById('app-screen').classList.remove('hidden');
}

function setupEventListeners() {
  // Auth tabs
  document.querySelectorAll('.auth-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      const target = tab.dataset.tab;
      document.getElementById('login-form').classList.toggle('hidden', target !== 'login');
      document.getElementById('register-form').classList.toggle('hidden', target !== 'register');
      hideError();
    });
  });

  // Login
  document.getElementById('login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('login-username').value.trim();
    const password = document.getElementById('login-password').value;
    try {
      const res = await fetch(`${API}/api/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      const data = await res.json();
      if (!res.ok) return showError(data.error);
      handleLogin(data);
    } catch (err) {
      showError(t('err_connection'));
    }
  });

  // Register
  document.getElementById('register-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const displayName = document.getElementById('reg-displayname').value.trim();
    const username = document.getElementById('reg-username').value.trim().toLowerCase();
    const password = document.getElementById('reg-password').value;
    try {
      const res = await fetch(`${API}/api/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password, displayName })
      });
      const data = await res.json();
      if (!res.ok) return showError(data.error);
      handleLogin(data);
    } catch (err) {
      showError(t('err_connection'));
    }
  });

  // Settings
  document.getElementById('btn-settings').addEventListener('click', openSettings);
  document.getElementById('close-settings').addEventListener('click', closeSettings);
  document.getElementById('btn-logout').addEventListener('click', logout);

  // Settings tabs
  document.querySelectorAll('.settings-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.settings-tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.settings-content').forEach(c => c.classList.remove('active'));
      tab.classList.add('active');
      document.getElementById(`stab-${tab.dataset.stab}`).classList.add('active');
    });
  });

  // Profile save
  document.getElementById('btn-save-profile').addEventListener('click', saveProfile);

  // Avatar select
  document.getElementById('avatar-select').addEventListener('change', () => {
    document.getElementById('settings-avatar').textContent = document.getElementById('avatar-select').value;
  });

  // Theme select
  document.querySelectorAll('.theme-option').forEach(opt => {
    opt.addEventListener('click', () => selectTheme(opt));
  });

  // PRO request
  document.getElementById('btn-request-pro').addEventListener('click', requestPro);

  // Search
  document.getElementById('search-users').addEventListener('input', filterContacts);

  // Message input
  const msgInput = document.getElementById('message-input');
  msgInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });

  msgInput.addEventListener('input', () => {
    autoResize(msgInput);
    handleTyping();
  });

  document.getElementById('btn-send').addEventListener('click', sendMessage);

  // Emoji
  document.getElementById('btn-emoji').addEventListener('click', toggleEmojiPicker);
  populateEmojis('smileys');

  document.querySelectorAll('.emoji-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.emoji-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      populateEmojis(tab.dataset.cat);
    });
  });

  // Back button (mobile)
  document.getElementById('btn-back').addEventListener('click', () => {
    document.getElementById('sidebar').classList.remove('mobile-hidden');
    document.getElementById('active-chat').classList.add('hidden');
    document.getElementById('empty-state').classList.remove('hidden');
    activeChat = null;
  });

  // Close pickers on outside click
  document.addEventListener('click', (e) => {
    if (!e.target.closest('#emoji-picker') && !e.target.closest('#btn-emoji')) {
      document.getElementById('emoji-picker').classList.add('hidden');
    }
    if (!e.target.closest('#reaction-picker')) {
      document.getElementById('reaction-picker').classList.add('hidden');
    }
    closeContextMenu();
  });

  // Close modal on overlay click
  document.getElementById('settings-modal').addEventListener('click', (e) => {
    if (e.target === document.getElementById('settings-modal')) closeSettings();
  });
}

function showError(msg) {
  const el = document.getElementById('auth-error');
  el.textContent = msg;
  el.classList.remove('hidden');
}

function hideError() {
  document.getElementById('auth-error').classList.add('hidden');
}

function handleLogin(data) {
  token = data.token;
  currentUser = data.user;
  localStorage.setItem('chatly_token', token);
  showApp();
  loadApp();
}

async function loadApp() {
  try {
    const res = await fetch(`${API}/api/me`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    if (!res.ok) {
      logout();
      return;
    }
    currentUser = await res.json();
    updateUI();
    connectSocket();
    loadContacts();
  } catch {
    logout();
  }
}

function updateUI() {
  if (!currentUser) return;

  const avatar = currentUser.avatar || '😎';
  document.getElementById('my-avatar').textContent = avatar;
  document.getElementById('my-name').textContent = currentUser.displayName;
  document.getElementById('settings-avatar').textContent = avatar;

  // PRO badge
  const proBadge = document.getElementById('my-pro-badge');
  if (currentUser.isPro) {
    proBadge.classList.remove('hidden');
  } else {
    proBadge.classList.add('hidden');
  }

  // Apply theme
  applyTheme(currentUser.isPro ? (currentUser.theme || 'default') : 'default');

  // Update settings fields
  document.getElementById('edit-displayname').value = currentUser.displayName;
  document.getElementById('edit-bio').value = currentUser.bio || '';
  document.getElementById('edit-username').value = currentUser.username;
  document.getElementById('avatar-select').value = currentUser.avatar || '😎';

  updateProStatus();
  updateThemeGrid();
}

function applyTheme(theme) {
  // Keep only theme-* classes
  document.body.className = document.body.className
    .split(' ')
    .filter(c => !c.startsWith('theme-') || c === '')
    .join(' ')
    .trim();
  if (theme && theme !== 'default') {
    document.body.classList.add(`theme-${theme}`);
  }
  // Re-apply translations in case lang-switcher changed body class
  applyTranslations();
}

function updateProStatus() {
  const area = document.getElementById('pro-status-area');
  const btn = document.getElementById('btn-request-pro');

  if (currentUser.isPro) {
    area.className = 'pro-status active-pro';
    area.innerHTML = `${t('pro_active')}<br><span style="font-size:12px;opacity:0.8">${t('pro_active_sub')}</span>`;
    btn.classList.add('hidden');
  } else if (proRequestPending) {
    area.className = 'pro-status pending-pro';
    area.innerHTML = `${t('pro_pending')}<br><span style="font-size:12px;opacity:0.8">${t('pro_pending_sub')}</span>`;
    btn.classList.add('hidden');
  } else {
    area.className = 'pro-status no-pro';
    area.innerHTML = `${t('pro_free')}<br><span style="font-size:12px;opacity:0.8">${t('pro_free_sub')}</span>`;
    btn.classList.remove('hidden');
    btn.disabled = false;
    btn.innerHTML = t('pro_request_btn');
  }
}

function updateThemeGrid() {
  document.querySelectorAll('.theme-option').forEach(opt => {
    const theme = opt.dataset.theme;
    if (theme === currentUser.theme) {
      opt.classList.add('selected');
    } else {
      opt.classList.remove('selected');
    }
    if (currentUser.isPro && theme !== 'default') {
      opt.classList.remove('pro-locked');
      opt.classList.add('unlocked');
    }
  });

  if (currentUser.isPro) {
    document.getElementById('theme-note-pro').classList.remove('hidden');
    document.getElementById('theme-note-free').classList.add('hidden');
  } else {
    document.getElementById('theme-note-pro').classList.add('hidden');
    document.getElementById('theme-note-free').classList.remove('hidden');
  }
}

// ===== SOCKET =====
function connectSocket() {
  socket = io({ auth: { token } });

  socket.on('connect', () => {
    console.log('🔌 Connected to Chatly server');
  });

  socket.on('disconnect', () => {
    console.log('🔌 Disconnected');
  });

  socket.on('message:new', (msg) => {
    if (msg.to === currentUser.username) {
      lastMessages[msg.from] = msg;
      if (activeChat === msg.from) {
        appendMessage(msg);
        scrollToBottom();
        markAsRead(msg.from);
      } else {
        unreadCounts[msg.from] = (unreadCounts[msg.from] || 0) + 1;
        renderContacts();
      }
    }
  });

  socket.on('message:sent', (msg) => {
    if (activeChat === msg.to) {
      lastMessages[msg.to] = msg;
      appendMessage(msg);
      scrollToBottom();
    }
    renderContacts();
  });

  socket.on('user:typing', ({ from, typing }) => {
    if (from === activeChat) {
      const el = document.getElementById('typing-indicator');
      if (typing) {
        document.getElementById('typing-name').textContent = getDisplayName(from);
        el.classList.remove('hidden');
      } else {
        el.classList.add('hidden');
      }
    }
  });

  socket.on('user:status', ({ username, status }) => {
    if (status === 'online') {
      onlineUsers.add(username);
    } else {
      onlineUsers.delete(username);
    }
    if (username === activeChat) {
      updateChatHeader();
    }
    renderContacts();
  });

  socket.on('message:readUpdate', ({ chatUser }) => {
    if (chatUser === activeChat) {
      loadMessages(activeChat);
    }
  });

  socket.on('pro:granted', (user) => {
    currentUser = user;
    updateUI();
    showToast(t('pro_granted_toast'), 'pro');
  });

  socket.on('pro:removed', (user) => {
    currentUser = user;
    updateUI();
    showToast(t('pro_removed_toast'), 'info');
  });

  socket.on('message:reaction', ({ msg }) => {
    if (activeChat) {
      loadMessages(activeChat);
    }
  });

  socket.on('message:pinUpdate', ({ msg }) => {
    if (activeChat) {
      loadMessages(activeChat);
    }
  });
}

// ===== CONTACTS =====
async function loadContacts() {
  try {
    const res = await fetch(`${API}/api/users`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const users = await res.json();

    // Load last messages for all users
    for (const u of users) {
      try {
        const mRes = await fetch(`${API}/api/messages/${u.username}`, {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        const msgs = await mRes.json();
        if (msgs.length > 0) {
          lastMessages[u.username] = msgs[msgs.length - 1];
        }
      } catch {}
    }

    renderContacts(users);
  } catch (err) {
    console.error('Load contacts error:', err);
  }
}

function renderContacts(users = null) {
  const container = document.getElementById('contacts-list');
  if (!users) {
    users = container._users || [];
  }
  container._users = users;

  const searchTerm = document.getElementById('search-users').value.toLowerCase();
  let filtered = users.filter(u =>
    u.displayName.toLowerCase().includes(searchTerm) ||
    u.username.toLowerCase().includes(searchTerm)
  );

  // Sort by last message time
  filtered.sort((a, b) => {
    const aTime = lastMessages[a.username]?.time || '';
    const bTime = lastMessages[b.username]?.time || '';
    return bTime.localeCompare(aTime);
  });

  container.innerHTML = filtered.map(u => {
    const lastMsg = lastMessages[u.username];
    const unread = unreadCounts[u.username] || 0;
    const isOnline = onlineUsers.has(u.username);
    const isActive = activeChat === u.username;
    const lastMsgText = lastMsg ? lastMsg.text : t('no_messages');
    const lastMsgTime = lastMsg ? formatTime(lastMsg.time) : '';
    const proBadge = u.isPro ? '<span class="contact-pro-badge">PRO</span>' : '';

    return `
      <div class="contact-item ${isActive ? 'active' : ''}" data-user="${u.username}" onclick="openChat('${u.username}')">
        <div class="avatar">${u.avatar || '😎'}</div>
        <span class="status-dot ${isOnline ? 'online' : 'offline'}"></span>
        <div class="contact-info">
          <div class="contact-name-row">
            <span class="contact-name">${escapeHTML(u.displayName)}</span>
            ${proBadge}
          </div>
          <div class="contact-last-msg">${escapeHTML(lastMsgText)}</div>
        </div>
        <div class="contact-meta">
          <span class="contact-time">${lastMsgTime}</span>
          ${unread > 0 ? `<span class="contact-unread">${unread}</span>` : ''}
        </div>
      </div>
    `;
  }).join('');
}

function filterContacts() {
  const container = document.getElementById('contacts-list');
  const users = container._users || [];
  renderContacts(users);
}

// ===== CHAT =====
async function openChat(username) {
  activeChat = username;
  unreadCounts[username] = 0;
  renderContacts();

  document.getElementById('empty-state').classList.add('hidden');
  document.getElementById('active-chat').classList.remove('hidden');

  // Mobile
  document.getElementById('sidebar').classList.add('mobile-hidden');

  updateChatHeader();
  await loadMessages(username);
  markAsRead(username);

  document.getElementById('message-input').focus();
}

function updateChatHeader() {
  if (!activeChat) return;
  const container = document.getElementById('contacts-list');
  const users = container._users || [];
  const user = users.find(u => u.username === activeChat);
  if (!user) return;

  document.getElementById('chat-avatar').textContent = user.avatar || '😎';
  document.getElementById('chat-user-name').textContent = user.displayName + (user.isPro ? ' 💎' : '');

  const isOnline = onlineUsers.has(activeChat);
  const statusEl = document.getElementById('chat-user-status');
  statusEl.textContent = isOnline ? t('online') : t('offline');
  statusEl.className = `chat-user-status ${isOnline ? '' : 'offline'}`;
}

async function loadMessages(username) {
  try {
    const res = await fetch(`${API}/api/messages/${username}`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const messages = await res.json();
    renderMessages(messages);
    scrollToBottom();
    updatePinnedBar(messages);
  } catch (err) {
    console.error('Load messages error:', err);
  }
}

function renderMessages(messages) {
  const container = document.getElementById('messages-container');
  let html = '';
  let lastDate = '';

  messages.forEach(msg => {
    const date = formatDate(msg.time);
    if (date !== lastDate) {
      html += `<div class="msg-date-divider"><span>${date}</span></div>`;
      lastDate = date;
    }

    const isOwn = msg.from === currentUser.username;
    const timeStr = formatTimeShort(msg.time);
    const readMark = isOwn && msg.read ? '<span class="msg-read">✓✓</span>' : (isOwn ? '<span class="msg-read" style="opacity:0.4">✓</span>' : '');
    const pinMark = msg.pinned ? `<div class="msg-pin-indicator">${t('pinned')}</div>` : '';

    let reactionsHtml = '';
    if (msg.reactions && msg.reactions.length > 0) {
      const grouped = {};
      msg.reactions.forEach(r => {
        if (!grouped[r.emoji]) grouped[r.emoji] = 0;
        grouped[r.emoji]++;
      });
      reactionsHtml = '<div class="msg-reactions">' +
        Object.entries(grouped).map(([emoji, count]) =>
          `<span class="msg-reaction">${emoji} <span class="reaction-count">${count}</span></span>`
        ).join('') + '</div>';
    }

    html += `
      <div class="message ${isOwn ? 'own' : 'other'}" data-msg-id="${msg.id}" oncontextmenu="showContextMenu(event, '${msg.id}', ${isOwn})">
        ${!isOwn ? `<div class="msg-sender">${escapeHTML(getDisplayName(msg.from))}</div>` : ''}
        <div class="msg-text">${formatMsgText(msg.text)}</div>
        <div class="msg-time">${timeStr} ${readMark}</div>
        ${reactionsHtml}
        ${pinMark}
      </div>
    `;
  });

  container.innerHTML = html;

  // Add double-click for reactions (PRO only)
  if (currentUser?.isPro) {
    container.querySelectorAll('.message').forEach(el => {
      el.addEventListener('dblclick', (e) => {
        e.preventDefault();
        showReactionPicker(e, el.dataset.msgId);
      });
    });
  }
}

function appendMessage(msg) {
  const container = document.getElementById('messages-container');
  const isOwn = msg.from === currentUser.username;
  const timeStr = formatTimeShort(msg.time);
  const readMark = isOwn && msg.read ? '<span class="msg-read">✓✓</span>' : (isOwn ? '<span class="msg-read" style="opacity:0.4">✓</span>' : '');

  const div = document.createElement('div');
  div.className = `message ${isOwn ? 'own' : 'other'}`;
  div.dataset.msgId = msg.id;

  if (currentUser?.isPro) {
    div.addEventListener('dblclick', (e) => {
      e.preventDefault();
      showReactionPicker(e, msg.id);
    });
  }

  div.oncontextmenu = (e) => showContextMenu(e, msg.id, isOwn);

  div.innerHTML = `
    ${!isOwn ? `<div class="msg-sender">${escapeHTML(getDisplayName(msg.from))}</div>` : ''}
    <div class="msg-text">${formatMsgText(msg.text)}</div>
    <div class="msg-time">${timeStr} ${readMark}</div>
  `;

  container.appendChild(div);
}

function formatMsgText(text) {
  let escaped = escapeHTML(text);
  escaped = escaped.replace(/\*\*(.+?)\*\*/g, '<b>$1</b>');
  escaped = escaped.replace(/\*(.+?)\*/g, '<i>$1</i>');
  escaped = escaped.replace(/(https?:\/\/[^\s]+)/g, '<a href="$1" target="_blank" rel="noopener" style="color:inherit;text-decoration:underline">$1</a>');
  return escaped;
}

function updatePinnedBar(messages) {
  const pinned = messages.filter(m => m.pinned);
  const bar = document.getElementById('pinned-bar');
  if (pinned.length > 0 && currentUser?.isPro) {
    bar.classList.remove('hidden');
    document.getElementById('pinned-text').textContent = pinned[pinned.length - 1].text;
  } else {
    bar.classList.add('hidden');
  }
}

function scrollToBottom() {
  const container = document.getElementById('messages-container');
  setTimeout(() => {
    container.scrollTop = container.scrollHeight;
  }, 50);
}

function sendMessage() {
  const input = document.getElementById('message-input');
  const text = input.value.trim();
  if (!text || !activeChat || !socket) return;

  socket.emit('message:send', { to: activeChat, text, type: 'text' });
  input.value = '';
  autoResize(input);
}

function handleTyping() {
  if (!socket || !activeChat) return;
  socket.emit('user:typing', { to: activeChat, typing: true });
  clearTimeout(typingTimeout);
  typingTimeout = setTimeout(() => {
    socket.emit('user:typing', { to: activeChat, typing: false });
  }, 2000);
}

async function markAsRead(username) {
  if (!username) return;
  try {
    await fetch(`${API}/api/messages/${username}/read`, {
      method: 'PUT',
      headers: { 'Authorization': `Bearer ${token}` }
    });
  } catch {}
}

// ===== CONTEXT MENU =====
function showContextMenu(e, msgId, isOwn) {
  e.preventDefault();
  closeContextMenu();
  contextMsgId = msgId;

  const msg = document.querySelector(`[data-msg-id="${msgId}"]`);
  if (!msg) return;

  const menu = document.createElement('div');
  menu.className = 'msg-context-menu show';
  menu.id = 'context-menu';

  if (currentUser?.isPro) {
    menu.innerHTML += `<button class="msg-context-btn pro-only" onclick="reactToMsg('${msgId}')">${t('ctx_react')}</button>`;
    menu.innerHTML += `<button class="msg-context-btn pro-only" onclick="pinMsg('${msgId}')">${t('ctx_pin')}</button>`;
  }
  menu.innerHTML += `<button class="msg-context-btn" onclick="copyMsg('${msgId}')">${t('ctx_copy')}</button>`;

  msg.style.position = 'relative';
  msg.appendChild(menu);

  if (isOwn) {
    menu.style.right = '10px';
  } else {
    menu.style.left = '10px';
  }
  menu.style.top = '-10px';
}

function closeContextMenu() {
  const existing = document.getElementById('context-menu');
  if (existing) existing.remove();
}

async function reactToMsg(msgId) {
  closeContextMenu();
  if (!socket || !activeChat) return;

  const btn = document.querySelector(`[data-msg-id="${msgId}"]`);
  if (!btn) return;

  const picker = document.getElementById('reaction-picker');
  picker.classList.remove('hidden');

  const rect = btn.getBoundingClientRect();
  picker.style.top = (rect.top - 50) + 'px';
  picker.style.left = rect.left + 'px';

  picker.querySelectorAll('.reaction-btn').forEach(b => {
    b.onclick = () => {
      socket.emit('message:react', { to: activeChat, msgId, emoji: b.dataset.emoji });
      picker.classList.add('hidden');
    };
  });
}

async function pinMsg(msgId) {
  closeContextMenu();
  if (!socket || !activeChat) return;
  socket.emit('message:pin', { to: activeChat, msgId });
}

function copyMsg(msgId) {
  closeContextMenu();
  const msg = document.querySelector(`[data-msg-id="${msgId}"] .msg-text`);
  if (msg) {
    navigator.clipboard.writeText(msg.textContent).then(() => {
      showToast(t('copied'), 'success');
    });
  }
}

// ===== EMOJI PICKER =====
function toggleEmojiPicker() {
  document.getElementById('emoji-picker').classList.toggle('hidden');
}

function populateEmojis(category) {
  const grid = document.getElementById('emoji-grid');
  const emojis = EMOJIS[category] || [];
  grid.innerHTML = emojis.map(e =>
    `<button class="emoji-item" onclick="insertEmoji('${e}')">${e}</button>`
  ).join('');
}

function insertEmoji(emoji) {
  const input = document.getElementById('message-input');
  input.value += emoji;
  input.focus();
  autoResize(input);
}

// ===== SETTINGS =====
function openSettings() {
  document.getElementById('settings-modal').classList.remove('hidden');
  updateUI();
}

function closeSettings() {
  document.getElementById('settings-modal').classList.add('hidden');
}

async function saveProfile() {
  const displayName = document.getElementById('edit-displayname').value.trim();
  const bio = document.getElementById('edit-bio').value.trim();
  const avatar = document.getElementById('avatar-select').value;

  try {
    const res = await fetch(`${API}/api/profile`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ displayName, bio, avatar })
    });
    const data = await res.json();
    currentUser = data;
    updateUI();
    showToast(t('profile_saved'), 'success');
  } catch {
    showToast(t('profile_error'), 'error');
  }
}

function selectTheme(opt) {
  const theme = opt.dataset.theme;
  if (theme !== 'default' && !currentUser?.isPro) {
    showToast(t('theme_need_pro'), 'info');
    return;
  }

  document.querySelectorAll('.theme-option').forEach(o => o.classList.remove('selected'));
  opt.classList.add('selected');

  applyTheme(theme);

  fetch(`${API}/api/profile`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify({ theme })
  }).then(r => r.json()).then(data => {
    currentUser = data;
  });
}

async function requestPro() {
  const btn = document.getElementById('btn-request-pro');
  const msgEl = document.getElementById('pro-request-msg');

  try {
    const res = await fetch(`${API}/api/request-pro`, {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await res.json();

    if (res.ok) {
      proRequestPending = true;
      msgEl.textContent = t('pro_request_sent');
      msgEl.className = 'pro-request-msg info';
      msgEl.classList.remove('hidden');
      btn.disabled = true;
      btn.textContent = '⏳ ...';
      updateProStatus();
      showToast(t('pro_request_sent'), 'info');
    } else {
      if (data.error === 'Request already pending') {
        proRequestPending = true;
        msgEl.textContent = t('pro_already_pending');
        msgEl.className = 'pro-request-msg info';
        msgEl.classList.remove('hidden');
        btn.disabled = true;
        updateProStatus();
      } else if (data.error === 'Already PRO') {
        msgEl.textContent = t('pro_already');
        msgEl.className = 'pro-request-msg success';
        msgEl.classList.remove('hidden');
      } else {
        msgEl.textContent = '❌ ' + data.error;
        msgEl.className = 'pro-request-msg success';
        msgEl.classList.remove('hidden');
      }
    }
  } catch {
    showToast(t('err_connection'), 'error');
  }
}

function logout() {
  token = null;
  currentUser = null;
  activeChat = null;
  localStorage.removeItem('chatly_token');
  if (socket) socket.disconnect();
  showAuth();
  document.body.className = '';
}

// ===== UTILS =====
function escapeHTML(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function formatTime(iso) {
  const d = new Date(iso);
  return d.toLocaleTimeString('uk-UA', { hour: '2-digit', minute: '2-digit' });
}

function formatTimeShort(iso) {
  return formatTime(iso);
}

function formatDate(iso) {
  const d = new Date(iso);
  const today = new Date();
  if (d.toDateString() === today.toDateString()) return t('today');
  const yesterday = new Date(today);
  yesterday.setDate(yesterday.getDate() - 1);
  if (d.toDateString() === yesterday.toDateString()) return t('yesterday');
  return d.toLocaleDateString('uk-UA', { day: 'numeric', month: 'long' });
}

function getDisplayName(username) {
  const container = document.getElementById('contacts-list');
  const users = container._users || [];
  const user = users.find(u => u.username === username);
  return user ? user.displayName : username;
}

function autoResize(textarea) {
  textarea.style.height = 'auto';
  textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
}

function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 4000);
}
