const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');
const path = require('path');
const readline = require('readline');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const JWT_SECRET = 'chatly-secret-key-2024-super-secure';
const DATA_FILE = path.join(__dirname, 'data.json');

// ========== DATA STORAGE ==========
let db = {
  users: {},
  messages: {},
  proRequests: []
};

function loadDB() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const raw = fs.readFileSync(DATA_FILE, 'utf8');
      db = JSON.parse(raw);
      if (!db.proRequests) db.proRequests = [];
      console.log('📂 Database loaded successfully');
    }
  } catch (e) {
    console.log('⚠️  Creating new database');
  }
}

function saveDB() {
  try {
    const dir = path.dirname(DATA_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2));
  } catch (e) {
    console.error('Save error:', e.message);
  }
}

// Auto-save every 10 seconds
setInterval(saveDB, 10000);

// ========== MIDDLEWARE ==========
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

function authenticateToken(req, res, next) {
  const token = req.headers['authorization']?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'No token' });
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch {
    return res.status(403).json({ error: 'Invalid token' });
  }
}

// ========== AUTH ROUTES ==========
app.post('/api/register', (req, res) => {
  const { username, password, displayName } = req.body;
  if (!username || !password || !displayName) {
    return res.status(400).json({ error: 'All fields required' });
  }
  if (username.length < 3) return res.status(400).json({ error: 'Username min 3 chars' });
  if (password.length < 4) return res.status(400).json({ error: 'Password min 4 chars' });
  if (db.users[username.toLowerCase()]) {
    return res.status(400).json({ error: 'Username already taken' });
  }

  const hashedPassword = bcrypt.hashSync(password, 10);
  db.users[username.toLowerCase()] = {
    id: uuidv4(),
    username: username.toLowerCase(),
    displayName,
    password: hashedPassword,
    avatar: null,
    bio: '',
    status: 'online',
    isPro: false,
    proExpiry: null,
    theme: 'default',
    customColor: null,
    createdAt: new Date().toISOString(),
    lastSeen: new Date().toISOString()
  };

  saveDB();
  const token = jwt.sign({ username: username.toLowerCase(), id: db.users[username.toLowerCase()].id }, JWT_SECRET);
  res.json({ token, user: sanitizeUser(db.users[username.toLowerCase()]) });
});

app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  const user = db.users[username.toLowerCase()];
  if (!user || !bcrypt.compareSync(password, user.password)) {
    return res.status(400).json({ error: 'Invalid credentials' });
  }

  user.lastSeen = new Date().toISOString();
  user.status = 'online';
  saveDB();

  const token = jwt.sign({ username: user.username, id: user.id }, JWT_SECRET);
  res.json({ token, user: sanitizeUser(user) });
});

// ========== USER ROUTES ==========
app.get('/api/users', authenticateToken, (req, res) => {
  const users = Object.values(db.users)
    .filter(u => u.username !== req.user.username)
    .map(sanitizeUser);
  res.json(users);
});

app.get('/api/me', authenticateToken, (req, res) => {
  const user = db.users[req.user.username];
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json(sanitizeUser(user));
});

app.put('/api/profile', authenticateToken, (req, res) => {
  const user = db.users[req.user.username];
  if (!user) return res.status(404).json({ error: 'User not found' });

  const { displayName, bio, avatar, theme, customColor } = req.body;
  if (displayName) user.displayName = displayName;
  if (bio !== undefined) user.bio = bio;
  if (avatar !== undefined) user.avatar = avatar;
  if (theme && user.isPro) user.theme = theme;
  if (customColor && user.isPro) user.customColor = customColor;

  saveDB();
  res.json(sanitizeUser(user));
});

app.post('/api/request-pro', authenticateToken, (req, res) => {
  const user = db.users[req.user.username];
  if (!user) return res.status(404).json({ error: 'User not found' });
  if (user.isPro) return res.status(400).json({ error: 'Already PRO' });

  const existing = db.proRequests.find(r => r.username === user.username && r.status === 'pending');
  if (existing) return res.status(400).json({ error: 'Request already pending' });

  const request = {
    id: uuidv4(),
    username: user.username,
    displayName: user.displayName,
    requestedAt: new Date().toISOString(),
    status: 'pending'
  };

  db.proRequests.push(request);
  saveDB();

  console.log('\n' + '💎'.repeat(20));
  console.log(`  📨 NEW PRO REQUEST from @${user.username} (${user.displayName})`);
  console.log(`  Type: pro ${user.username}  to approve`);
  console.log('💎'.repeat(20) + '\n');

  res.json({ message: 'PRO request sent! Wait for admin approval.' });
});

// ========== MESSAGE ROUTES ==========
function getChatId(u1, u2) {
  return [u1, u2].sort().join('::');
}

app.get('/api/messages/:username', authenticateToken, (req, res) => {
  const chatId = getChatId(req.user.username, req.params.username);
  const msgs = db.messages[chatId] || [];
  res.json(msgs);
});

app.post('/api/messages/:username', authenticateToken, (req, res) => {
  const { text, type = 'text' } = req.body;
  const recipient = req.params.username;
  if (!db.users[recipient]) return res.status(404).json({ error: 'User not found' });

  const chatId = getChatId(req.user.username, recipient);
  if (!db.messages[chatId]) db.messages[chatId] = [];

  const msg = {
    id: uuidv4(),
    from: req.user.username,
    to: recipient,
    text,
    type,
    time: new Date().toISOString(),
    read: false,
    reactions: [],
    pinned: false
  };

  db.messages[chatId].push(msg);

  // Keep last 500 messages per chat
  if (db.messages[chatId].length > 500) {
    db.messages[chatId] = db.messages[chatId].slice(-500);
  }

  saveDB();
  res.json(msg);
});

// Pin/Unpin message (PRO only)
app.put('/api/messages/:chatUser/pin/:msgId', authenticateToken, (req, res) => {
  const user = db.users[req.user.username];
  if (!user?.isPro) return res.status(403).json({ error: 'PRO feature only' });

  const chatId = getChatId(req.user.username, req.params.chatUser);
  const msgs = db.messages[chatId] || [];
  const msg = msgs.find(m => m.id === req.params.msgId);
  if (!msg) return res.status(404).json({ error: 'Message not found' });

  msg.pinned = !msg.pinned;
  saveDB();
  res.json(msg);
});

// React to message (PRO only)
app.put('/api/messages/:chatUser/react/:msgId', authenticateToken, (req, res) => {
  const user = db.users[req.user.username];
  if (!user?.isPro) return res.status(403).json({ error: 'PRO feature only' });

  const { emoji } = req.body;
  const chatId = getChatId(req.user.username, req.params.chatUser);
  const msgs = db.messages[chatId] || [];
  const msg = msgs.find(m => m.id === req.params.msgId);
  if (!msg) return res.status(404).json({ error: 'Message not found' });

  if (!msg.reactions) msg.reactions = [];
  const existing = msg.reactions.findIndex(r => r.user === req.user.username);
  if (existing >= 0) {
    msg.reactions[existing].emoji = emoji;
  } else {
    msg.reactions.push({ user: req.user.username, emoji });
  }

  saveDB();
  res.json(msg);
});

// Mark messages as read
app.put('/api/messages/:username/read', authenticateToken, (req, res) => {
  const chatId = getChatId(req.user.username, req.params.username);
  const msgs = db.messages[chatId] || [];
  msgs.forEach(m => {
    if (m.to === req.user.username && !m.read) m.read = true;
  });
  saveDB();
  res.json({ success: true });
});

// ========== HELPER ==========
function sanitizeUser(user) {
  if (!user) return null;
  return {
    id: user.id,
    username: user.username,
    displayName: user.displayName,
    avatar: user.avatar,
    bio: user.bio,
    status: user.status,
    isPro: user.isPro,
    proExpiry: user.proExpiry,
    theme: user.theme,
    customColor: user.customColor,
    lastSeen: user.lastSeen,
    createdAt: user.createdAt
  };
}

// ========== SOCKET.IO ==========
const onlineUsers = new Map();

io.use((socket, next) => {
  const token = socket.handshake.auth.token;
  if (!token) return next(new Error('No token'));
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    socket.user = decoded;
    next();
  } catch {
    next(new Error('Invalid token'));
  }
});

io.on('connection', (socket) => {
  const username = socket.user.username;
  onlineUsers.set(username, socket.id);

  if (db.users[username]) {
    db.users[username].status = 'online';
    db.users[username].lastSeen = new Date().toISOString();
  }
  io.emit('user:status', { username, status: 'online' });

  console.log(`✅ @${username} connected (${onlineUsers.size} online)`);

  socket.on('message:send', (data) => {
    const { to, text, type = 'text' } = data;
    if (!to || !text) return;

    const chatId = getChatId(username, to);
    if (!db.messages[chatId]) db.messages[chatId] = [];

    const msg = {
      id: uuidv4(),
      from: username,
      to,
      text,
      type,
      time: new Date().toISOString(),
      read: false,
      reactions: [],
      pinned: false
    };

    db.messages[chatId].push(msg);
    if (db.messages[chatId].length > 500) {
      db.messages[chatId] = db.messages[chatId].slice(-500);
    }

    const recipientSocket = onlineUsers.get(to);
    if (recipientSocket) {
      io.to(recipientSocket).emit('message:new', msg);
    }
    socket.emit('message:sent', msg);

    // Typing stopped
    const recipientSocket2 = onlineUsers.get(to);
    if (recipientSocket2) {
      io.to(recipientSocket2).emit('user:typing', { from: username, typing: false });
    }
  });

  socket.on('message:read', (data) => {
    const { chatUser } = data;
    const chatId = getChatId(username, chatUser);
    const msgs = db.messages[chatId] || [];
    let changed = false;
    msgs.forEach(m => {
      if (m.to === username && !m.read) { m.read = true; changed = true; }
    });
    if (changed) {
      const otherSocket = onlineUsers.get(chatUser);
      if (otherSocket) {
        io.to(otherSocket).emit('message:readUpdate', { chatUser: username });
      }
    }
  });

  socket.on('message:react', (data) => {
    const user = db.users[username];
    if (!user?.isPro) return;

    const { to, msgId, emoji } = data;
    const chatId = getChatId(username, to);
    const msgs = db.messages[chatId] || [];
    const msg = msgs.find(m => m.id === msgId);
    if (!msg) return;

    if (!msg.reactions) msg.reactions = [];
    const existing = msg.reactions.findIndex(r => r.user === username);
    if (existing >= 0) {
      msg.reactions[existing].emoji = emoji;
    } else {
      msg.reactions.push({ user: username, emoji });
    }

    const recipientSocket = onlineUsers.get(to);
    if (recipientSocket) {
      io.to(recipientSocket).emit('message:reaction', { chatId, msg });
    }
    socket.emit('message:reaction', { chatId, msg });
  });

  socket.on('message:pin', (data) => {
    const user = db.users[username];
    if (!user?.isPro) return;

    const { to, msgId } = data;
    const chatId = getChatId(username, to);
    const msgs = db.messages[chatId] || [];
    const msg = msgs.find(m => m.id === msgId);
    if (!msg) return;

    msg.pinned = !msg.pinned;

    const recipientSocket = onlineUsers.get(to);
    if (recipientSocket) {
      io.to(recipientSocket).emit('message:pinUpdate', { chatId, msg });
    }
    socket.emit('message:pinUpdate', { chatId, msg });
  });

  socket.on('user:typing', (data) => {
    const { to, typing } = data;
    const recipientSocket = onlineUsers.get(to);
    if (recipientSocket) {
      io.to(recipientSocket).emit('user:typing', { from: username, typing });
    }
  });

  socket.on('disconnect', () => {
    onlineUsers.delete(username);
    if (db.users[username]) {
      db.users[username].status = 'offline';
      db.users[username].lastSeen = new Date().toISOString();
    }
    io.emit('user:status', { username, status: 'offline' });
    console.log(`❌ @${username} disconnected (${onlineUsers.size} online)`);
    saveDB();
  });
});

// ========== ADMIN CONSOLE ==========
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

function showHelp() {
  console.log('\n📡 Chatly Admin Console:');
  console.log('  pro <username>       - Grant PRO status');
  console.log('  remove-pro <username> - Remove PRO status');
  console.log('  list                  - List all users');
  console.log('  requests              - Show PRO requests');
  console.log('  online                - Show online users');
  console.log('  help                  - Show this help');
  console.log('');
}

function processCommand(cmd) {
  const parts = cmd.trim().split(/\s+/);
  const command = parts[0]?.toLowerCase();

  switch (command) {
    case 'pro': {
      const target = parts[1]?.toLowerCase();
      if (!target || !db.users[target]) {
        console.log('❌ User not found');
        break;
      }
      db.users[target].isPro = true;
      db.users[target].proExpiry = 'lifetime';

      // Update request status
      db.proRequests.forEach(r => {
        if (r.username === target && r.status === 'pending') r.status = 'approved';
      });

      saveDB();

      // Notify user if online
      const socketId = onlineUsers.get(target);
      if (socketId) {
        io.to(socketId).emit('pro:granted', sanitizeUser(db.users[target]));
      }

      console.log(`💎 PRO granted to @${target}!`);
      break;
    }
    case 'remove-pro': {
      const target = parts[1]?.toLowerCase();
      if (!target || !db.users[target]) {
        console.log('❌ User not found');
        break;
      }
      db.users[target].isPro = false;
      db.users[target].proExpiry = null;
      db.users[target].theme = 'default';
      db.users[target].customColor = null;
      saveDB();

      const socketId = onlineUsers.get(target);
      if (socketId) {
        io.to(socketId).emit('pro:removed', sanitizeUser(db.users[target]));
      }

      console.log(`🔻 PRO removed from @${target}`);
      break;
    }
    case 'list': {
      console.log('\n👥 All Users:');
      Object.values(db.users).forEach(u => {
        const pro = u.isPro ? ' 💎' : '';
        const on = onlineUsers.has(u.username) ? ' 🟢' : ' ⚫';
        console.log(`  ${on} @${u.username} (${u.displayName})${pro}`);
      });
      console.log('');
      break;
    }
    case 'requests': {
      const pending = db.proRequests.filter(r => r.status === 'pending');
      if (pending.length === 0) {
        console.log('📭 No pending PRO requests');
      } else {
        console.log('\n📬 Pending PRO Requests:');
        pending.forEach(r => {
          console.log(`  📨 @${r.username} (${r.displayName}) - ${new Date(r.requestedAt).toLocaleString()}`);
        });
        console.log('');
      }
      break;
    }
    case 'online': {
      console.log(`\n🟢 Online: ${onlineUsers.size}`);
      onlineUsers.forEach((sid, uname) => {
        console.log(`  @${uname}`);
      });
      console.log('');
      break;
    }
    case 'help':
      showHelp();
      break;
    default:
      if (cmd.trim()) console.log('❓ Unknown command. Type "help"');
  }
  rl.prompt();
}

rl.on('line', processCommand);
rl.on('close', () => { saveDB(); process.exit(0); });

// ========== START SERVER ==========
loadDB();

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log('');
  console.log('  ╔══════════════════════════════════════╗');
  console.log('  ║     💬 CHATLY MESSENGER SERVER 💬     ║');
  console.log('  ║                                      ║');
  console.log(`  ║  Running on http://localhost:${PORT}     ║`);
  console.log(`  ║  Users: ${Object.keys(db.users).length.toString().padEnd(5)}  Messages: ${Object.values(db.messages).reduce((a, m) => a + m.length, 0).toString().padEnd(5)}    ║`);
  console.log('  ║  Type "help" for admin commands      ║');
  console.log('  ╚══════════════════════════════════════╝');
  console.log('');
  rl.prompt();
});
